package com.umgi.es.sftp.gateway.common.util;

public class SFTPGatewayConstants {
	
	public static final String SERVICE_CONFIG_BEAN =  "sftpGatewayServiceConfigBean"; 
	public static final String SOURCE_ABSOLUTE_FILE_PATH = "sourceAbsoluteFilePath";
	public static final String SOURCE_FILE_INPUT_STREAM_OBJECT = "sourceFileInputStreamObject";
	public static final String DESTINATION_SERVICE_CONFIG_OBJECT="destinationServiceConfigObj";
	
	public static final String OVERRIDE_EXISTING_REMOTE_FILE_FLAG = "override.existing.remotefile.flag";
	public static final String TMP_REMOTE_FILE_NAME_PREFIX_FLAG = "tmp.remote.fileName.prefix.value";
	public static final String TMP_REMOTE_FILE_NAME_SUFFIX_FLAG = "tmp.remote.fileName.suffix.value";
	public static final String TMP_REMOTE_DIRECTORY_FLAG = "tmp.remotedirectory.flag";
	public static final String TMP_REMOTE_DIRECTORY_LOCATION = "tmp.remotedirectory.location";
	public static final String SOURCE_DIRECTORY_LOCATION = "sourceDirectory";
	public static final String REMOTE_DIRECTORY_LOCATION = "remoteDirectory";
	public static final String SFTP_AUTHENTICATION_TYPE_PPK_USR_PASSPHRASE = "sftp.authenticationtype.privatekey.username.passphrase";
	public static final String SFTP_AUTHENTICATION_TYPE_PPK_USR_ONLY = "sftp.authenticationtype.privatekey.username";
	public static final String SFTP_PRIVATE_KEY_ABSOLUTE_PATH = "sftp.privatekey.absolute.path";
	public static final String SFTP_PASSPHRASE = "passphrase";
	public static final String SFTP_FILE_SIZE_CHECK = "sftp.file.size.check";
	
	public static final String SOURCE_FILE_NAME = "sourceFileName";
	public static final String SFTP_REMOTE_DIRECTORY_LOCATION="sftpRemoteDirectoryLocation";
	public static final String SFTP_REMOTE_FILENAME="sftpRemoteFileName";
	
	public static final String SFTP_DESTINATION_PROPERTIES_FILE_PREFIX = "es_config_";
	public static final String SFTP_DESTINATION_PROPERTIES_FILE_SUFFIX = "_sftp.properties";
	public static final String SFTP_HOLDSFTP_STATUS = "hold.ftp.flag";
	public static final String SFTP_HOLDSFTP_VARIABLE = "holdValue";
	public static final Object SFTP_HOLDSFTP_FILE_PATTERNS = "hold.ftp.filePatterns";
	public static final String SFTP_HOLDSFTP_FILE_PATTERNS_VARIABLE = "holdPattern";
	
	public static final String EMPTYCHECKREQUIRED = "emptyCheck.required";
	public static final String LOGGER_MESSAGE_ID = "messageId";
	public static final String LOGGER_MESSAGE_SOURCE = "messageSource";
	public static final String LOGGER_MESSAGE_ACTION = "messageAction";
	public static final String LOGGER_RESOURCE_ID = "resourceId";
	public static final String LOGGER_RESOURCE_NAME = "resourceName";
	
	public static final String FAILED_SFTP_FILE_DETAILS = "failedSftpedFileDetails";
	
	public static final String RETYABLE_FLAG = "retryableFlag"; 
	public static final String SERVICE_NAME = "SFTP GATEWAY";
	public static final String ACTUAL_PAYLOAD = "actualPayload";
	public static final String IS_TRIGGER_ENABLE = "isTriggerEnable";
	
	public static final String EMPTY_PASSWORD = "";
	
	public static final String LOGGER_NAME = "com.umgi.es.enterprise.sftp.gateway";
	
	public static final String SERVICE = "SFTP-GATEWAY";
	
	public static final String POSTTRANSFER_COMMAND = "postTransfer.localCommand";
	
	public static final String DELETE = "delete";
	
	public static final String COPY = "copy";
	
	public static final String RENAME = "rename";
	
	public static final String ARCHIVED_FILENAME = "archivedFileName";
	
	public static final String SOURCE_ABSOLUTE_PATH="sourceAbsoluteFilePath";
	
	public static final String ABSOLUTE_ARCHIVE_FILENAME = "absoluteArchiveFilename";
	
	public static final String IS_EMAIL_TRIGGERED = "isEmailTriggered";
	
	
}
