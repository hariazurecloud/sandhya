package com.umgi.es.sftp.enterprisemessages;

import java.net.InetAddress;
import java.util.Date;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;

import com.umgi.es.common.util.pojo.xml.EnterpriseException;
import com.umgi.es.common.util.pojo.xml.EnterpriseException.OriginalMessage;
import com.umgi.es.connectors.enterpriseglobalutilities.EnterpriseGlobalutilitiesConnector;
import com.umgi.es.sftp.gateway.common.util.ErrorCategory;
import com.umgi.es.sftp.gateway.common.util.SFTPGatewayConstants;

public class GenerateEnterpriseException implements Callable {

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {

		MuleMessage muleMessage = eventContext.getMessage();
		EnterpriseException enterpriseException = new EnterpriseException();
		EnterpriseGlobalutilitiesConnector enterpriseUtils = new EnterpriseGlobalutilitiesConnector();

		enterpriseException.setExceptionId(java.util.UUID.randomUUID()
				.toString());

		if (null != muleMessage.getProperty(
				SFTPGatewayConstants.LOGGER_MESSAGE_ID, PropertyScope.SESSION)) {
			enterpriseException.setMessageId(muleMessage.getProperty(
					SFTPGatewayConstants.LOGGER_MESSAGE_ID,
					PropertyScope.SESSION).toString());
		} else {
			enterpriseException.setMessageId(java.util.UUID.randomUUID()
					.toString());
		}

		enterpriseException.setCreatedUtc(enterpriseUtils
				.getDateAsXMLGregorianCalendar(new Date()));
		enterpriseException.setService(SFTPGatewayConstants.SERVICE_NAME);
		enterpriseException.setErrorCode(muleMessage.getExceptionPayload()
				.getCode());

		// If any files are failed then mention the failed file details in
		// description.
		if (muleMessage.getInvocationProperty("isEmptyFile") != null && (Boolean)muleMessage.getInvocationProperty("isEmptyFile") == true) {
			enterpriseException.setDescription("Input File is Empty, so stopping further processing");
			enterpriseException.setDetails(muleMessage
					.getInvocationProperty(
							SFTPGatewayConstants.FAILED_SFTP_FILE_DETAILS)
					.toString());
			
		} else if(null != muleMessage
				.getInvocationProperty(SFTPGatewayConstants.FAILED_SFTP_FILE_DETAILS) ){
			
			enterpriseException.setDescription(muleMessage
					.getInvocationProperty(
							SFTPGatewayConstants.FAILED_SFTP_FILE_DETAILS)
					.toString());
			enterpriseException
					.setDetails("Please check respective log file for the reason of each file failure");
			
		} 
		else {
			enterpriseException.setDescription(muleMessage
					.getExceptionPayload().getException().getMessage());
			enterpriseException.setDetails(muleMessage.getExceptionPayload()
					.getException().getCause().toString());
		}

		// Check if retryable is true set Retryable is true.
		if (null != muleMessage
				.getInvocationProperty(SFTPGatewayConstants.RETYABLE_FLAG)
				&& muleMessage.getInvocationProperty(
						SFTPGatewayConstants.RETYABLE_FLAG).toString() == "true") {
			enterpriseException.setCategory(ErrorCategory.RETRYABLE
					.getErrorCategory());
			enterpriseException.setRetriable(true);
		}else{
			enterpriseException.setCategory(ErrorCategory.ERROR
					.getErrorCategory());
			enterpriseException.setRetriable(false);
		}

		enterpriseException.setService(SFTPGatewayConstants.SERVICE_NAME);
		enterpriseException
				.setMachine(InetAddress.getLocalHost().getHostName());

		// Set Resource id
		if (null != muleMessage.getProperty(
				SFTPGatewayConstants.LOGGER_RESOURCE_NAME,
				PropertyScope.SESSION)) {
			enterpriseException.setResourceName(muleMessage.getProperty(
					SFTPGatewayConstants.LOGGER_RESOURCE_NAME,
					PropertyScope.SESSION).toString());
		}
		// Set Resource name
		if (null != muleMessage.getProperty(
				SFTPGatewayConstants.LOGGER_RESOURCE_ID, PropertyScope.SESSION)) {
			enterpriseException.setResourceId(muleMessage.getProperty(
					SFTPGatewayConstants.LOGGER_RESOURCE_ID,
					PropertyScope.SESSION).toString());
		}

		if (null != muleMessage
				.getInvocationProperty(SFTPGatewayConstants.ACTUAL_PAYLOAD)) {
			OriginalMessage originalMessage = new OriginalMessage();
			originalMessage.setAny(muleMessage
					.getInvocationProperty(SFTPGatewayConstants.ACTUAL_PAYLOAD));
			enterpriseException.setOriginalMessage(originalMessage);
		}

		return enterpriseException;
	}

}
