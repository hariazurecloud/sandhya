package com.umgi.es.sftp.gateway.common.util;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;
import org.mule.util.FileUtils;

import com.umgi.es.common.util.serviceconfig.EnterpriseServiceConfig;

public class FileManipulation implements Callable {

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {

		MuleMessage message = eventContext.getMessage();
		EnterpriseServiceConfig serviceConfig = message.getProperty(
				SFTPGatewayConstants.DESTINATION_SERVICE_CONFIG_OBJECT,
				PropertyScope.INVOCATION);

		String sourceFileLocation = message.getProperty(
				SFTPGatewayConstants.SOURCE_ABSOLUTE_PATH, PropertyScope.SESSION);
		File sourceFile = new File(sourceFileLocation);
		DateFormat utcDateFormat = new SimpleDateFormat(
				serviceConfig.get("archive.filename.timestamp.pattern"));
		Date date = new Date();
		String archivedFileName = message.getProperty(
				SFTPGatewayConstants.ABSOLUTE_ARCHIVE_FILENAME, PropertyScope.SESSION).toString()
				+ utcDateFormat.format(date);
		
		message.setInvocationProperty(SFTPGatewayConstants.ARCHIVED_FILENAME,
				archivedFileName);
		String localCommand = serviceConfig.get(SFTPGatewayConstants.POSTTRANSFER_COMMAND);
		String fileStatus = "0";
		try {
			if (localCommand.equalsIgnoreCase(SFTPGatewayConstants.RENAME)) {
				sourceFile.renameTo(new File(archivedFileName));
				fileStatus = "1";
			} else if (localCommand.equalsIgnoreCase(SFTPGatewayConstants.COPY)) {
				FileUtils.copyFile(sourceFile, new File(archivedFileName), true);
				fileStatus = "1";
			} else if (localCommand.equalsIgnoreCase(SFTPGatewayConstants.DELETE)) {
				sourceFile.delete();
				fileStatus = "1";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return fileStatus;
	}

}
