package com.umgi.es.sftp.gateway.common.util;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;
import org.springframework.core.io.ClassPathResource;
import com.umgi.es.common.util.serviceconfig.EnterpriseServiceConfig;

public class ServiceConfigHandler implements Callable {

	String configRoot = System.getProperty("env.configRoot");
	String decryptionAlgorithm = System.getProperty("env.decryptionAlgorithm");
	String decryptionPassword = System.getProperty("env.decryptionPassword");

	/*
	 * String configRoot =
	 * "http://esesbuat2.global.umusic.ext:7750/zuul/settings/dev/"; String
	 * decryptionAlgorithm = "PBEWithMD5AndDES"; String decryptionPassword =
	 * "badpassword1";
	 */

	public EnterpriseServiceConfig enterpriseServiceConfig = null;

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		
		MuleMessage muleMessage = eventContext.getMessage();
		String value = null;
		String holdFilePatterns = null;
		String fileName = null;
		String filePath = null;
		String isTriggerEnable = null;
		String isEmptyCheckReq = null;
		// Get Destination configuration properties file name.
		String propertyFileName = SFTPGatewayConstants.SFTP_DESTINATION_PROPERTIES_FILE_PREFIX
					+ muleMessage.getPayloadAsString().toLowerCase()
					+ SFTPGatewayConstants.SFTP_DESTINATION_PROPERTIES_FILE_SUFFIX;
		

		enterpriseServiceConfig = new EnterpriseServiceConfig();

		enterpriseServiceConfig.setDecryptionAlgorithm(decryptionAlgorithm);
		enterpriseServiceConfig.setDecryptionPassword(decryptionPassword);
		enterpriseServiceConfig.setConfigRoot(configRoot);
		enterpriseServiceConfig.setLocation(new ClassPathResource(
				propertyFileName));
		//check if the interface has hold sftp flag set
		value = enterpriseServiceConfig.get(SFTPGatewayConstants.SFTP_HOLDSFTP_STATUS);
		if(value==null){
			muleMessage.setInvocationProperty(SFTPGatewayConstants.SFTP_HOLDSFTP_VARIABLE,"false");
		}
		else{
			muleMessage.setInvocationProperty(SFTPGatewayConstants.SFTP_HOLDSFTP_VARIABLE,value);
		}
		isTriggerEnable = enterpriseServiceConfig.get(SFTPGatewayConstants.IS_TRIGGER_ENABLE);
		if(isTriggerEnable==null){
			muleMessage.setInvocationProperty(SFTPGatewayConstants.IS_TRIGGER_ENABLE, "false");
		}
		else{
			muleMessage.setInvocationProperty(SFTPGatewayConstants.IS_TRIGGER_ENABLE, isTriggerEnable); 
		}
		
		//check for empty file
		isEmptyCheckReq = enterpriseServiceConfig.get(SFTPGatewayConstants.EMPTYCHECKREQUIRED);
		if(isEmptyCheckReq != null && isEmptyCheckReq.equalsIgnoreCase("true")){
			muleMessage.setInvocationProperty("isEmptyCheckReq", true);
		}
		else{
			muleMessage.setInvocationProperty("isEmptyCheckReq", false);
		}
		//check if the interface has any hold file patterns defined
		holdFilePatterns = enterpriseServiceConfig.get(SFTPGatewayConstants.SFTP_HOLDSFTP_FILE_PATTERNS);
		filePath = muleMessage.getProperty(SFTPGatewayConstants.SOURCE_ABSOLUTE_FILE_PATH, PropertyScope.SESSION).toString();				
		fileName = filePath.substring(filePath.lastIndexOf("/") + 1);		
		if((value == null || !value.equalsIgnoreCase("true")) && holdFilePatterns != null){			
			for(String holdPattern: holdFilePatterns.split(",")){				
				if(fileName.matches(holdPattern.trim())){					
					muleMessage.setInvocationProperty(SFTPGatewayConstants.SFTP_HOLDSFTP_VARIABLE,"true");
					muleMessage.setInvocationProperty(SFTPGatewayConstants.SFTP_HOLDSFTP_FILE_PATTERNS_VARIABLE, holdPattern);
					break;
				}
			}
		}		
		
		//check email props
		String isEmailEnabled =enterpriseServiceConfig.get("sftp.email.enabled");
		String emailSubject =enterpriseServiceConfig.get("es.sftp.notification.info.smtp.email.subject");
		String infoEmailTo =enterpriseServiceConfig.get("es.sftp.notification.info.smtp.email.to");
		String infoEmailCC = enterpriseServiceConfig.get("es.sftp.notification.info.smtp.email.cc");
		String emailBody =enterpriseServiceConfig.get("es.sftp.notification.info.smtp.email.body");
		String errorEmailTo = enterpriseServiceConfig.get("es.sftp.notification.error.smtp.email.to");
		String errorEmailCC = enterpriseServiceConfig.get("es.sftp.notification.error.smtp.email.cc");
		String errorSubject =enterpriseServiceConfig.get("es.sftp.notification.error.smtp.email.subject");
		String errorBody= enterpriseServiceConfig.get("es.sftp.notification.error.smtp.email.body");
		
		
		if(isEmailEnabled!=null &&  isEmailEnabled.equalsIgnoreCase("true") ) {
			if(emailSubject != null && infoEmailTo != null && emailBody !=null && errorSubject != null && errorBody!= null && infoEmailCC !=null) {
				muleMessage.setInvocationProperty(SFTPGatewayConstants.IS_EMAIL_TRIGGERED, true);
				muleMessage.setInvocationProperty("successSubject", emailSubject);
				muleMessage.setInvocationProperty("infoEmailTo", infoEmailTo);
				muleMessage.setInvocationProperty("errorSubject", errorSubject);
				muleMessage.setInvocationProperty("infoEmailCC", infoEmailCC);
				muleMessage.setInvocationProperty("errorEmailTo", errorEmailTo);
				muleMessage.setInvocationProperty("errorEmailCC", errorEmailCC);
			}
			
		}else {
			muleMessage.setInvocationProperty(SFTPGatewayConstants.IS_EMAIL_TRIGGERED, false);
		}
		
		muleMessage.setInvocationProperty(
				SFTPGatewayConstants.DESTINATION_SERVICE_CONFIG_OBJECT,
				enterpriseServiceConfig);

		return muleMessage.getPayload();
	}

}
