package com.umgi.es.sftp.gateway.common.util;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.SAXException;

import com.umgi.es.common.util.log.enterpriselogger.EnterpriseLogger;

/*************************************************************************************************************************
 * File Name : SchemaValidation.java 
 * Author : kalyan.chakravarthy@invenio-solutions.com 
 * Date : 24-Feb-2014 
 * Description :The purpose of this class is to do validate the XML data against the Schema.
 *************************************************************************************************************************/
public class SchemaValidation {

	/**
	 * This method is used to validate XML data against the schema
	 * 
	 * @param xmlContent
	 *            source XML data
	 * @return Return XML data if validation success.
	 * @throws SAXException
	 * @throws IOException
	 */
	public String validateXML(String xmlContent, String xsdFilePath,
			String loggerName, String loggerServiceName) throws SAXException,
			IOException {

		EnterpriseLogger enterpriseLogger = new EnterpriseLogger(
				loggerName, loggerServiceName);
		
		try {

			enterpriseLogger.debug(null,null, "102655107",
					"XML schema validation started");
			enterpriseLogger.debug(null,null, "102655108", "xsd File Path: "
					+ xsdFilePath);
			// Read xsd file from classpath.
			File schemaFile = new File(getClass().getClassLoader()
					.getResource(xsdFilePath).getFile());

			Source xmlFile = new StreamSource(new StringReader(xmlContent));
			SchemaFactory schemaFactory = SchemaFactory
					.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
			Schema schema = schemaFactory.newSchema(schemaFile);

			// validate XML against the schema.
			Validator validator = schema.newValidator();
			validator.validate(xmlFile);
			enterpriseLogger.debug(null,null, "102655109",
					"XML schema validation successfully completed");
		} catch (NullPointerException e) {
			enterpriseLogger.error(null,null, "500655109",
					xsdFilePath+" file doesn't exist");
			throw new NullPointerException(xsdFilePath+" file doesn't exist");
		}
		return xmlContent;
	}

}
