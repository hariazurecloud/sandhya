package com.umgi.es.sftp.gateway.message.dispatchers;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import org.mule.api.MuleEvent;
import org.mule.api.MuleMessage;
import org.mule.api.endpoint.OutboundEndpoint;
import org.mule.api.transport.PropertyScope;
import org.mule.transport.AbstractMessageDispatcher;
import org.mule.transport.sftp.SftpClient;
import org.mule.transport.sftp.SftpConnector;
import org.mule.transport.sftp.SftpUtil;
import org.mule.transport.sftp.notification.SftpNotifier;

import com.umgi.es.common.util.log.enterpriselogger.EnterpriseLogger;
import com.umgi.es.common.util.pojo.xml.EnterpriseMessage;
import com.umgi.es.common.util.serviceconfig.EnterpriseServiceConfig;
import com.umgi.es.sftp.gateway.common.util.SFTPGatewayConstants;

public class CustomSftpMessageDispatcher extends AbstractMessageDispatcher {

	private SftpUtil sftpUtil = null;
	

	public CustomSftpMessageDispatcher(OutboundEndpoint endpoint) {
		super(endpoint);
		sftpUtil = new SftpUtil(endpoint);
	}

	protected void doDisconnect() throws Exception {
		// no op
	}

	protected void doDispose() {
		// no op
	}

	@SuppressWarnings("null")
	protected void doDispatch(MuleEvent event) throws Exception {

		MuleMessage muleMessage = event.getMessage();
		EnterpriseServiceConfig enterpriseServiceConfig = muleMessage
				.getInvocationProperty(SFTPGatewayConstants.DESTINATION_SERVICE_CONFIG_OBJECT);
		EnterpriseLogger logger = new EnterpriseLogger("com.umgi.es.enterprise.sftp.gateway", "SFTP-GATEWAY");
		EnterpriseMessage eMessage = muleMessage.getProperty("actualPayload", PropertyScope.INVOCATION);
		Boolean isFileExists = null;
		int maxRetryAttempts = Integer.parseInt(muleMessage.getProperty("maxRetryAttempts", PropertyScope.INVOCATION));
		int maxWaitMilliSeconds = Integer.parseInt(muleMessage.getProperty("maxWaitMilliSeconds", PropertyScope.INVOCATION));

		File file = new File(muleMessage
				.getProperty(SFTPGatewayConstants.SOURCE_ABSOLUTE_FILE_PATH
				, PropertyScope.SESSION).toString());
		String sourceFileName = muleMessage
				.getInvocationProperty(SFTPGatewayConstants.SOURCE_FILE_NAME);
		Boolean overrideExistingFileFlag = Boolean
				.valueOf(enterpriseServiceConfig
						.get(SFTPGatewayConstants.OVERRIDE_EXISTING_REMOTE_FILE_FLAG));
		String tmpFileNamePrefix = enterpriseServiceConfig
				.get(SFTPGatewayConstants.TMP_REMOTE_FILE_NAME_PREFIX_FLAG);
		String tmpFileNameSuffix = enterpriseServiceConfig
				.get(SFTPGatewayConstants.TMP_REMOTE_FILE_NAME_SUFFIX_FLAG);
		Boolean fileSizeCheck = Boolean
				.valueOf(enterpriseServiceConfig
						.get(SFTPGatewayConstants.SFTP_FILE_SIZE_CHECK));
		String tmpRemoteDirectoryPath = enterpriseServiceConfig
				.get(SFTPGatewayConstants.TMP_REMOTE_DIRECTORY_LOCATION);
		String actualRemoteDirectoryPath = enterpriseServiceConfig
				.get(SFTPGatewayConstants.REMOTE_DIRECTORY_LOCATION);
		String remoteFileAbsolutePath = actualRemoteDirectoryPath + "/"
				+ sourceFileName;
		if(actualRemoteDirectoryPath == null || actualRemoteDirectoryPath.trim().length() == 0){
			actualRemoteDirectoryPath = muleMessage.getProperty("sftpRemoteDirectoryLocation", PropertyScope.INVOCATION);
		}
		if(actualRemoteDirectoryPath == null){
			actualRemoteDirectoryPath = "";
		}
		String outputPattern = muleMessage
				.getInvocationProperty(SFTPGatewayConstants.SFTP_REMOTE_FILENAME);
		Boolean sftpAuthenticationTypePpkUsrPwdFlag = Boolean
				.valueOf(enterpriseServiceConfig
						.get(SFTPGatewayConstants.SFTP_AUTHENTICATION_TYPE_PPK_USR_PASSPHRASE));
		Boolean sftpAuthenticationTypePpkUsrOnlyFlag = Boolean
				.valueOf(enterpriseServiceConfig
						.get(SFTPGatewayConstants.SFTP_AUTHENTICATION_TYPE_PPK_USR_ONLY));
		String identityFile = enterpriseServiceConfig
				.get(SFTPGatewayConstants.SFTP_PRIVATE_KEY_ABSOLUTE_PATH);
		String passphrase = enterpriseServiceConfig
				.get(SFTPGatewayConstants.SFTP_PASSPHRASE);
	    SftpConnector connector = (SftpConnector)endpoint.getConnector();
		// Set identity file location to connector.
		if ((null != sftpAuthenticationTypePpkUsrPwdFlag && sftpAuthenticationTypePpkUsrPwdFlag)
				|| (null != sftpAuthenticationTypePpkUsrOnlyFlag && sftpAuthenticationTypePpkUsrOnlyFlag)) {
			connector.setIdentityFile(identityFile);
			if (null != sftpAuthenticationTypePpkUsrPwdFlag
					&& sftpAuthenticationTypePpkUsrPwdFlag) {
				
				// Set passphrase when authentication type is with privatekey, username and passphrase 
				connector.setPassphrase(passphrase);
			}
		}
		int retryCounter=0;
		String serviceName = (event.getFlowConstruct() == null) ? "UNKNOWN SERVICE"
				: event.getFlowConstruct().getName();
		SftpNotifier notifier = new SftpNotifier(connector, event.getMessage(),
				endpoint, serviceName);
		SftpClient client = null;
		Boolean isErrorOccured = false;
		try {
		// Get SFTP client object
			for(int i = 0; i<maxRetryAttempts; i++) {
			try {
				sftpUploadProcess(event,client, connector, notifier, actualRemoteDirectoryPath,  remoteFileAbsolutePath,
						  sourceFileName,  isFileExists, overrideExistingFileFlag,  outputPattern,  tmpFileNamePrefix,
						  tmpFileNameSuffix,  tmpRemoteDirectoryPath, logger,eMessage,fileSizeCheck,retryCounter,maxRetryAttempts,isErrorOccured,file);
				isErrorOccured = false;
				break;
			}catch (Exception e) {
				isErrorOccured = true;
					Thread.sleep(maxWaitMilliSeconds);
					logger.info(eMessage, null, "102014116", "SFTP process has failed trying to upload again "+e.getMessage());
					
			}
			}
			/*finally {
				if (client != null) {
					// If the connection fails, the client will be null, otherwise
					// disconnect.
					client.disconnect();
					connector.releaseClient(endpoint, client);
					logger.info(eMessage, null, "202014116", "SFTP source client released successfully");

					
				}
				connector.setIdentityFile(null);
				connector.setPassphrase(null);
				logger.info(eMessage, null, "202014116", "SFTP source connection disconnected successfully");
				
			}*/
			if(isErrorOccured) {
				throw new Exception("file "+sourceFileName+" has failed to upload to target after max retries");
			}
		} finally {
			if (client != null) {
				// If the connection fails, the client will be null, otherwise
				// disconnect.
				client.disconnect();
				connector.releaseClient(endpoint, client);
				logger.info(eMessage, null, "202014116", "SFTP source client released successfully");

				
			}
			connector.setIdentityFile(null);
			connector.setPassphrase(null);
			connector.disconnect();
			logger.info(eMessage, null, "202014116", "SFTP source connection disconnected successfully");
			
		}

	}
	
	private Boolean sftpUploadProcess(MuleEvent event,SftpClient client,SftpConnector connector,SftpNotifier notifier,String actualRemoteDirectoryPath, String remoteFileAbsolutePath,
			 String sourceFileName, Boolean isFileExists,Boolean overrideExistingFileFlag, String outputPattern, String tmpFileNamePrefix,
			 String tmpFileNameSuffix, String tmpRemoteDirectoryPath,EnterpriseLogger logger,EnterpriseMessage eMessage, Boolean fileSizeCheck, int counter, int maxRetryAttempts,Boolean retryFlag, File file) throws Exception {
		
		// Get SFTP client object
		client = connector.createSftpClient(endpoint, notifier);

			try {
				// Set true if file already exists.
				String workingDir=endpoint.getEndpointURI().getPath();	
				if(actualRemoteDirectoryPath != null && workingDir !=null && workingDir.length()> 1) {
					String diff=StringUtils.difference(workingDir, actualRemoteDirectoryPath);
					if(diff !=null && diff.length() > 0){
						workingDir = diff;
					}
					else{
						workingDir = actualRemoteDirectoryPath;
					}
					
					if(actualRemoteDirectoryPath.equalsIgnoreCase(workingDir))
					remoteFileAbsolutePath = sourceFileName;
				}
				if((client.listFiles(remoteFileAbsolutePath))!=null)					
					isFileExists = client.listFiles(remoteFileAbsolutePath).length > 0;
			} catch (IOException ioe) {
				isFileExists = false;
			}
			// File already exists in remote server
			if ( null != isFileExists
					&& isFileExists) {

				// If overridden configuration is true then delete existing file
				// and
				// transfer new file
				if (null != overrideExistingFileFlag
						&& overrideExistingFileFlag) {
					// Delete existing file
					client.deleteFile(remoteFileAbsolutePath);

					// Check temporary filename or directory and upload
					implTempFileOrTempDir(event, outputPattern,
							tmpFileNamePrefix, tmpFileNameSuffix, sourceFileName, 
							tmpRemoteDirectoryPath, actualRemoteDirectoryPath,client, connector,file);
				}

				// If overridden configuration is false then throw an exception
				else if (null != overrideExistingFileFlag
						&& !overrideExistingFileFlag) {
					throw new IOException("File already exists: "+sourceFileName);
				}

				// If overridden configuration is not configured.
				else {
					throw new Exception(
							"Overridden Configuration is not available.");
				}
			} else {
				// Check temporary filename or directory and upload
				implTempFileOrTempDir(event, outputPattern, tmpFileNamePrefix,
						tmpFileNameSuffix, sourceFileName,
						tmpRemoteDirectoryPath, actualRemoteDirectoryPath,client, connector, file);
			}
			
			///PUMGI/BI/hv/tra_in//Test_file.txt file uploaded with 0 byte to  /PUMGI/BI/hv/tra_in/ Proceeding to upload again 
			if(null != fileSizeCheck && fileSizeCheck  ) {
			long sizeofFile= client.getSize(remoteFileAbsolutePath);
			if(sizeofFile>0 ) {
				logger.info(eMessage, null, "102014116", remoteFileAbsolutePath+" file uploaded to "+actualRemoteDirectoryPath+" SFTP server ");
			}else if(counter !=maxRetryAttempts) {
				// File already exists in remote server with 0 byte size Uploading again 
				Thread.sleep(60000);
				counter++;
				logger.info(eMessage, null, "102014116", remoteFileAbsolutePath+" file uploaded with 0 byte to  "+actualRemoteDirectoryPath+" Proceeding to upload again ");
				client.deleteFile(remoteFileAbsolutePath);
				logger.info(eMessage, null, "102014116", remoteFileAbsolutePath+" file is deleted from "+actualRemoteDirectoryPath);
				sftpUploadProcess(event,client, connector, notifier, actualRemoteDirectoryPath,  remoteFileAbsolutePath,
						  sourceFileName,  isFileExists, overrideExistingFileFlag,  outputPattern,  tmpFileNamePrefix,
						  tmpFileNameSuffix,  tmpRemoteDirectoryPath,logger,eMessage,fileSizeCheck,counter,maxRetryAttempts,retryFlag, file);
			} else {
				retryFlag=true;
				logger.error(eMessage, null, "102014116"," MAX tries have reached while trying to re-upload file "+sourceFileName +" which was uploaded with 0 byte size");
			}
			}
			else {
				logger.info(eMessage, null, "102014116", remoteFileAbsolutePath+" file uploaded to "+actualRemoteDirectoryPath+" SFTP server ");
			}
			if (client != null) {
				// If the connection fails, the client will be null, otherwise
				// disconnect.
				client.disconnect();
				connector.releaseClient(endpoint, client);
				logger.info(eMessage, null, "202014116", "SFTP source client released successfully");

				
			}
			return retryFlag;
		
	}

	private void upload(MuleEvent event,SftpClient client, SftpConnector connector, File file) throws Exception {

		
		String filename = buildFilename(event,connector);
		InputStream inputStream = generateInputStream(event,file);
		boolean useTempDir = false;
		String transferFilename = null;

		try {
			String destDir = endpoint.getEndpointURI().getPath();

			// Duplicate Handling
			filename = client.duplicateHandling(destDir, filename,
					sftpUtil.getDuplicateHandling());
			transferFilename = filename;

			useTempDir = sftpUtil.isUseTempDirOutbound();
			if (useTempDir) {
				// TODO move to a init-method like doConnect?
				// cd to tempDir and create it if it doesn't already exist
				sftpUtil.cwdToTempDirOnOutbound(client, destDir);

				// Add unique file-name (if configured) for use during transfer
				// to
				// temp-dir
				boolean addUniqueSuffix = sftpUtil
						.isUseTempFileTimestampSuffix();
				if (addUniqueSuffix) {
					transferFilename = sftpUtil
							.createUniqueSuffix(transferFilename);
				}
			}

			// send file over sftp
			// choose appropriate writing mode
			if (sftpUtil.getDuplicateHandling().equals(
					SftpConnector.PROPERTY_DUPLICATE_HANDLING_APPEND)) {
				client.storeFile(transferFilename, inputStream,
						SftpClient.WriteMode.APPEND);
			} else {
				client.storeFile(transferFilename, inputStream);
			}

			if (useTempDir) {
				// Move the file to its final destination
				client.rename(transferFilename, destDir + "/" + filename);
			}

			
			} catch (Exception e) {
			
			sftpUtil.setErrorOccurredOnInputStream(inputStream);

			if (useTempDir) {
				// Cleanup the remote temp dir from the not fullt completely
				// transferred file!
				String tempDir = sftpUtil.getTempDirOutbound();
				sftpUtil.cleanupTempDir(client, transferFilename, tempDir);
			}
			throw e;
		} finally {
  		//inputStream.close();
		}
	}

	private void implTempFileOrTempDir(MuleEvent event, String outputPattern,
			String tmpFilenamePrefix, String tmpFileNameSuffix,
			String actualFileName, String tmpDirectoryPath,
			String actualDirectoryPath, SftpClient client, SftpConnector connector, File file) throws Exception {

		// transfer file with 'tmp' prefix and rename to actual
		// filename.
		if ((null != tmpFilenamePrefix && !tmpFilenamePrefix.equals("")) 
				|| (null != tmpFileNameSuffix && !tmpFileNameSuffix.equals(""))) {

			upload(event,client,connector,file);
			client.rename(outputPattern, actualDirectoryPath + "/"
					+ actualFileName);

			// Transfer to temp directory and move it to actual
			// directory
		} else if (null != tmpDirectoryPath && !tmpDirectoryPath.equals("")) {

			// Upload file to temporary location and move it to actual location.
			moveTmpDirToActualDir(event, tmpDirectoryPath, actualDirectoryPath,
					actualFileName,client,connector,file);
		} else {

			// Upload file to remote server
			upload(event,client,connector,file);
		}
	}

	private void moveTmpDirToActualDir(MuleEvent event,
			String tmpDirectoryPath, String actualDirectoryPath,
			String actualFileName,SftpClient client,SftpConnector connector,File file) throws Exception {

		// Upload file to remote server
		upload(event,client,connector, file);

		// Move file from temporary location to actual location.
		client.rename(actualFileName, actualDirectoryPath + "/"
				+ actualFileName);
	}

	private InputStream generateInputStream(MuleEvent event, File file) throws IOException {
		FileInputStream fileInputStream = new FileInputStream(file);
		
		Object data = fileInputStream;
		// byte[], String, or InputStream payloads supported.

		byte[] buf;
		InputStream inputStream;

		if (data instanceof byte[]) {
			buf = (byte[]) data;
			inputStream = new ByteArrayInputStream(buf);
		} else if (data instanceof InputStream) {
			inputStream = (InputStream) data;
		} else if (data instanceof String) {
			inputStream = new ByteArrayInputStream(((String) data).getBytes());
		} else {
			throw new IllegalArgumentException(
					"Unexpected message type: java.io.InputStream, byte[], or String expected. Got "
							+ data.getClass().getName());
		}
		return inputStream;
	}

	@SuppressWarnings("deprecation")
	private String buildFilename(MuleEvent event,SftpConnector connector) {
		MuleMessage muleMessage = event.getMessage();
		String outPattern = (String) endpoint
				.getProperty(SftpConnector.PROPERTY_OUTPUT_PATTERN);
		if (outPattern == null) {
			outPattern = (String) muleMessage.getProperty(
					SftpConnector.PROPERTY_OUTPUT_PATTERN,
					connector.getOutputPattern());
		}
		String filename = connector.getFilenameParser().getFilename(
				muleMessage, outPattern);
		if (filename == null) {
			filename = (String) event.getMessage().findPropertyInAnyScope(
					SftpConnector.PROPERTY_FILENAME, null);
		}
		return filename;
	}

	protected MuleMessage doSend(MuleEvent event) throws Exception {
		doDispatch(event);
		return event.getMessage();
	}

}
