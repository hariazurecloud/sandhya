package com.umgi.es.sftp.gateway.common.util;

/**
 * @author kalyan
 * Logger levels
 */
public enum ErrorCategory {

	ERROR("Error"),	WARN("Warn"), FATAL("Fatal"),RETRYABLE("Retryable");
	 
	private String errorCategory;
 
	private ErrorCategory(String s) {
		errorCategory = s;
	}
 
	public String getErrorCategory() {
		return errorCategory;
	}
	
}
